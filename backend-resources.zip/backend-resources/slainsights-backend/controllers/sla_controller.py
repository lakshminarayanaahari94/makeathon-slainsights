from fastapi import APIRouter, HTTPException, Response
from config import AZURE_STORAGE_CONTAINER_NAME, AZURE_STORAGE_SUMMARY_CONTAINER_NAME
from services.blob_service import download_blob_from_container
from services.db_service import get_all_documents, get_document_by_id
import json

router = APIRouter()

@router.get("/info")
async def get_documents_info():
    try:
        documents = get_all_documents()
        # return {"documents": documents}
        return documents
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

@router.get("/summary/{document_name}")
async def view_document(document_name: str):
    try:
        # Download the summary document from blob storage directly using the document name
        summary_content = download_blob_from_container(AZURE_STORAGE_SUMMARY_CONTAINER_NAME, document_name)
        summary_json = json.loads(summary_content)

        return summary_json
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@router.get("/document/{document_name}")
async def get_document_file(document_name: str):
    try:

        # Download the summary document from blob storage
        file_content = download_blob_from_container(AZURE_STORAGE_CONTAINER_NAME, document_name)

        return Response(content=file_content, media_type="application/octet-stream")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
