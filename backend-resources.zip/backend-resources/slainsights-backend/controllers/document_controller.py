from fastapi import APIRouter, UploadFile, File, HTTPException
from services.blob_service import upload_file_to_blob, delete_blob_from_container
from services.db_service import add_document_record, delete_document_record
from typing import List
from config import AZURE_STORAGE_CONTAINER_NAME, AZURE_STORAGE_SUMMARY_CONTAINER_NAME

router = APIRouter()

@router.post("/upload")
async def upload_files(files: List[UploadFile] = File(...)):
    try:
        uploaded_files = []
        for file in files:
            file_url = upload_file_to_blob(file.file, file.filename)
            document_record = add_document_record(file.filename)
            uploaded_files.append({
                "file_url": file_url,
                "document_id": document_record.documentid,
                "document_name": document_record.documentname
            })
        return {"uploaded_files": uploaded_files}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/delete/{document_id}")
async def delete_document(document_id: int):
    try:
        document = delete_document_record(document_id)
        if not document:
            raise HTTPException(status_code=404, detail="Document not found")

        # Delete documents from blob storage
        delete_blob_from_container(AZURE_STORAGE_CONTAINER_NAME, document.documentname)
        delete_blob_from_container(AZURE_STORAGE_SUMMARY_CONTAINER_NAME, document.summarydocument)

        return {"message": "Document deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

