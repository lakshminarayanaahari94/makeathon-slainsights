import sys
from fastapi import APIRouter, HTTPException, Body
from services.json_service import prepare_context
from services.llm_service import collect_responses, prepare_combined_sets, query_llm, summarize_responses
from services.db_service import get_all_summary_documents
from services.blob_service import download_blob_from_container
from config import AZURE_STORAGE_SUMMARY_CONTAINER_NAME
import json
import os

router = APIRouter()

@router.post("/query/llm")
def query_with_llm(question: str = Body(..., embed=True), set_size: int = 3):
    """
    Use LLM to process JSON objects and respond to queries.
    """
    try:
        # Get all summary documents
        summary_documents = get_all_summary_documents()
        
        # Download and combine documents into sets
        combined_sets = []
        for doc_name in summary_documents:
            file_content = download_blob_from_container(AZURE_STORAGE_SUMMARY_CONTAINER_NAME, doc_name)
            combined_sets.append(json.loads(file_content))  # Convert file content to string
        
        # Prepare combined sets
        combined_sets = prepare_combined_sets(combined_sets, set_size)
        
        # Collect responses for all sets
        responses = collect_responses(combined_sets, question)

        print(responses)
        
        # Summarize all responses
        final_summary = summarize_responses(responses)
        
        # return {"question": question, "answer": final_summary}
        return {"question": question, "answer": final_summary}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
