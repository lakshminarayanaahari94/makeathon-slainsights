import os

# OpenAI API Key configuration
AZURE_OPENAI_KEY = '5otmCEXX2DkfO99fOpSlzH6j7q6X8CU9mEVRuhbb5vtG83GzNGUiJQQJ99BAACL93NaXJ3w3AAAAACOGWbVT'

# OpenAI model to use
# OPENAI_MODEL = 'gpt-35-turbo'
AZURE_OPENAI_ENDPOINT = 'https://ai-harisowmya10942082ai258095855737.openai.azure.com/'
AZURE_OPENAI_DEPLOYMENT_ID = 'gpt-4o'

# Azure Storage configuration
AZURE_STORAGE_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=sladocstg;AccountKey=DaV0vOvicGoYf8Uz3Zr1q1Bblkl2dhy/wQpFTZjCSmjuxM4y8fhQkpQhaUaQXbkxV1VIuvsFrds3+AStb1bezg==;EndpointSuffix=core.windows.net'
AZURE_STORAGE_CONTAINER_NAME = 'sladoc'
AZURE_STORAGE_SUMMARY_CONTAINER_NAME = 'slasummary'

# Database configuration
DATABASE_URL = 'postgresql://postgres:postgres@localhost:5432/postgres'
