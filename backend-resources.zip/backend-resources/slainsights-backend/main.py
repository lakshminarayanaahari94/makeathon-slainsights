from fastapi import FastAPI
from controllers import document_controller, llm_controller, health_controller,sla_controller

app = FastAPI()

# Include routes from controllers
app.include_router(health_controller.router)
app.include_router(llm_controller.router)
app.include_router(document_controller.router, prefix="/document")
app.include_router(sla_controller.router, prefix="/sla")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8080, reload=True)
