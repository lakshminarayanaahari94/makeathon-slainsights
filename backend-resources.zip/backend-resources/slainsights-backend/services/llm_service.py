import sys
from openai import AzureOpenAI
from config import AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_KEY, AZURE_OPENAI_DEPLOYMENT_ID
from services.json_service import prepare_context
import json

client = AzureOpenAI(azure_endpoint=AZURE_OPENAI_ENDPOINT, api_version="2024-02-01", api_key=AZURE_OPENAI_KEY)

def query_llm(prompt: str, max_tokens: int = 500, temperature: float = 0.7) -> str:
    try:
        response = client.chat.completions.create(
            model=AZURE_OPENAI_DEPLOYMENT_ID,
            messages=[
                {"role": "system", "content": "You are an AI assistant that answers questions based on provided JSON data."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=max_tokens,
            temperature=temperature
        )
        print(response.choices[0].message.content)
        return response.choices[0].message.content
    except Exception as e:
        raise RuntimeError(f"Error querying LLM: {str(e)}")

def summarize_responses(responses, max_tokens=500, temperature=0.7):
    prompt = f"""
    You are an AI assistant. The following are responses from multiple sets of question:\n
    
    {responses}
    #############################################\n
    Based on these responses, provide a summarized answer.
    """
    
    return query_llm(prompt, max_tokens=max_tokens, temperature=temperature)

def prepare_combined_sets(summary_documents, set_size):
    combined_sets = []
    for i in range(0, len(summary_documents), set_size):
        combined_set = summary_documents[i:i+set_size]
        combined_sets.append(combined_set)
        # print("Each combined set",combined_set)
    return combined_sets

def collect_responses(combined_sets, question):
    responses = []
    for combined_set in combined_sets:
        # context = json.loads(combined_set)
        print("inside_collect response",sys.getsizeof(combined_sets))
        print("Each combined set",combined_set)
        # context = combined_set
        print("context", sys.getsizeof(combined_sets))
        
        # with open('data/sample_data.json', 'r') as file:
        #     context = json.load(file)
        # print("context2", sys.getsizeof(context))
        prompt = f"""
        You are an AI assistant. The following are JSON objects representing SLA details:\n
        
        {combined_sets}
        #############################################\n
        Based on these JSON objects, answer the following question:\n
        {question}
        """
        response = query_llm(prompt)
        responses.append(response)
    return responses
