from azure.storage.blob import BlobServiceClient
from config import AZURE_STORAGE_CONNECTION_STRING, AZURE_STORAGE_CONTAINER_NAME, AZURE_STORAGE_SUMMARY_CONTAINER_NAME

blob_service_client = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION_STRING)
container_client = blob_service_client.get_container_client(AZURE_STORAGE_CONTAINER_NAME)

def upload_file_to_blob(file, filename):
    blob_client = container_client.get_blob_client(filename)
    blob_client.upload_blob(file)
    return blob_client.url

def delete_blob_from_container(container_name, blob_name):
    if not blob_name:
        raise ValueError("Blob name cannot be null or empty")
    container_client = blob_service_client.get_container_client(container_name)
    blob_client = container_client.get_blob_client(blob_name)
    blob_client.delete_blob()

def download_blob_from_container(container_name, blob_name):
    if not blob_name:
        raise ValueError("Blob name cannot be null or empty")
    try:
        container_client = blob_service_client.get_container_client(container_name)
        blob_client = container_client.get_blob_client(blob_name)
        download_stream = blob_client.download_blob()
        return download_stream.readall()
    except Exception as e:
        print(f"An error occurred while downloading the blob '{blob_name}': {e}")
        raise RuntimeError(f"An error occurred while downloading the blob '{blob_name}': {e}")