from sqlalchemy import create_engine, Column, Integer, String, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from config import DATABASE_URL

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class Document(Base):
    __tablename__ = 'documents'
    __table_args__ = {'schema': 'sla_insights'}
    documentid = Column(Integer, primary_key=True, index=True)
    documentname = Column(String, index=True)
    summarystatus = Column(String, default='Analysing')
    summarydocument = Column(Text, default=None)

Base.metadata.create_all(bind=engine)

def add_document_record(document_name):
    db = SessionLocal()
    document = Document(documentname=document_name)
    db.add(document)
    db.commit()
    db.refresh(document)
    db.close()
    return document

def delete_document_record(document_id):
    db = SessionLocal()
    document = db.query(Document).filter(Document.documentid == document_id).first()
    if document:
        db.delete(document)
        db.commit()
    db.close()
    return document

def get_all_documents():
    db = SessionLocal()
    documents = db.query(Document).all()
    db.close()
    return documents

def get_document_by_id(document_id):
    db = SessionLocal()
    document = db.query(Document).filter(Document.documentid == document_id).first()
    db.close()
    return document

def get_all_summary_documents():
    db = SessionLocal()
    documents = db.query(Document.summarydocument).all()
    db.close()
    return [doc.summarydocument for doc in documents if doc.summarydocument is not None]