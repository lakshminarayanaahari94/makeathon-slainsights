from fastapi import FastAPI
from controllers import llm_controller, health_controller

app = FastAPI()

# Include routes from controllers
app.include_router(health_controller.router)
app.include_router(llm_controller.router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
