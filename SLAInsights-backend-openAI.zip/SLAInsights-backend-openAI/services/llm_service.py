from openai import AzureOpenAI
from config import AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_KEY, AZURE_OPENAI_DEPLOYMENT_ID

client = AzureOpenAI(azure_endpoint=AZURE_OPENAI_ENDPOINT,  api_version = "2024-02-01",api_key=AZURE_OPENAI_KEY)

def query_llm(prompt: str, max_tokens: int = 500, temperature: float = 0.7) -> str:
    """
    """
    try:

        response = client.chat.completions.create(
            model=AZURE_OPENAI_DEPLOYMENT_ID,
            messages=[
                {"role": "system", "content": "You are an AI assistant that answers questions based on provided JSON data."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=max_tokens,
            temperature=temperature
        )
        print(response.choices[0].message.content)
        return response.choices[0].message.content
    except Exception as e:
        raise RuntimeError(f"Error querying LLM: {str(e)}")
