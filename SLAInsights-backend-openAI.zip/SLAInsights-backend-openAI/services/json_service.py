import json

def load_json_data(filepath: str) -> list:
    """
    Load JSON data from a file.
    """
    with open(filepath, "r") as file:
        return json.load(file)

def prepare_context(json_objects: list) -> str:
    """
    Convert JSON objects into a formatted string for LLM processing.
    """
    return json.dumps(json_objects, indent=2)
