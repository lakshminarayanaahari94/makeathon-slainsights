
from fastapi import APIRouter, HTTPException, Body
from services.json_service import load_json_data, prepare_context
from services.llm_service import query_llm
import os

router = APIRouter()

# Load sample JSON data
DATA_FILEPATH = os.path.join("data", "sample_data.json")
JSON_OBJECTS = load_json_data(DATA_FILEPATH)

@router.post("/query/llm")
def query_with_llm(question: str = Body(..., embed=True)):
    """
    Use LLM to process JSON objects and respond to queries.
    """
    try:
        # Prepare context from JSON objects
        context = prepare_context(JSON_OBJECTS)
        
        # Create the prompt for the LLM
        prompt = f"""
        You are an AI assistant. The following are JSON objects representing SLA details:\n
        
        {context}
        #############################################\n
        Based on these JSON objects, answer the following question:\n
        {question}
        """
        
        # Query the LLM
        answer = query_llm(prompt)
        
        return {"question": question, "answer": answer}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
