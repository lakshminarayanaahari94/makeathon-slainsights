import os

# OpenAI API Key configuration
AZURE_OPENAI_KEY = 'WqRr8seMsMWabY8Kz6CdPcy3jMx5iedBI4nXtm8R8qVs1iuTC64dJQQJ99BAACfhMk5XJ3w3AAAAACOGSa4L'

# OpenAI model to use
OPENAI_MODEL = 'gpt-35-turbo'
AZURE_OPENAI_ENDPOINT = 'https://haris-m5xro7mx-swedencentral.openai.azure.com/'
AZURE_OPENAI_DEPLOYMENT_ID = 'gpt-4'
